module.exports = {
  'name': 'ember-json-api',

  init: function () {
    this.treePaths.addon = 'src';
  }
};
